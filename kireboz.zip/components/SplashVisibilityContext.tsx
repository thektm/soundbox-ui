import React, { createContext, useCallback, useContext, useMemo, useState } from "react";

interface SplashVisibilityContextValue {
  splashVisible: boolean;
  completeSplash: () => void;
}

const SplashVisibilityContext = createContext<SplashVisibilityContextValue>({
  // The splash is visible on the very first client render. Starting with false
  // would allow guest actions/navigation to flash before effects run.
  splashVisible: true,
  completeSplash: () => {},
});

export const SplashVisibilityProvider = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  const [splashVisible, setSplashVisible] = useState(true);

  // Idempotent by design: Strict Mode, repeated readiness updates, or duplicate
  // completion attempts cannot reopen or complete the splash more than once.
  const completeSplash = useCallback(() => {
    setSplashVisible((current) => (current ? false : current));
  }, []);

  const value = useMemo(
    () => ({ splashVisible, completeSplash }),
    [completeSplash, splashVisible],
  );

  return (
    <SplashVisibilityContext.Provider value={value}>
      {children}
    </SplashVisibilityContext.Provider>
  );
};

export const useSplashVisibility = () => useContext(SplashVisibilityContext);
