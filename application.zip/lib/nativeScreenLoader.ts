import type { ElementType } from "react";
import { Capacitor } from "@capacitor/core";

type ScreenModule = { default: ElementType<any> };
type ScreenLoader = () => Promise<any>;

// Native navigation is intentionally ON-DEMAND. Nothing in this registry is
// warmed in the background. A module is evaluated only when Android is about
// to navigate to that screen, then retained by the browser module registry and
// this tiny component cache for subsequent visits/back navigation.
const screenLoaders: Record<string, ScreenLoader> = {
  home: () => import("../components/home"),
  search: () => import("../components/Search"),
  library: () => import("../components/LibraryScreen"),
  playlists: () => import("../components/Playlists"),
  profile: () =>
    typeof window !== "undefined" && window.matchMedia("(min-width: 1024px)").matches
      ? import("../components/DesktopProfile")
      : import("../components/Profile"),
  "downloads-history": () => import("../components/DownloadsHistory"),
  settings: () => import("../components/Settings"),

  "song-detail": () => import("../components/SongDetail"),
  "playlist-detail": () => import("../components/PlaylistDetail"),
  "user-playlist-detail": () => import("../components/UserPlaylistDetail"),
  "artist-detail": () => import("../components/ArtistDetail"),
  "artist-sub-page": () => import("../components/ArtistSubPage"),
  "album-detail": () => import("../components/AlbumDetail"),
  "user-detail": () => import("../components/UserDetail"),
  "chart-detail": () => import("../components/ChartPage"),
  "genre-detail": () => import("../components/GenrePage"),

  "followers-following": () => import("../components/FollowersFollowing"),
  "followed-artists": () => import("../components/FollowingArtistsPage"),
  "liked-songs": () => import("../components/LikedSongs"),
  "liked-albums": () => import("../components/LikedAlbums"),
  "liked-playlists": () => import("../components/LikedPlaylists"),
  "my-playlists": () => import("../components/MyPlaylists"),

  "popular-artists": () => import("../components/PopularArtistsPage"),
  "latest-releases": () => import("../components/LatestReleasesPage"),
  "popular-albums": () => import("../components/PopularAlbumsPage"),
  "new-discoveries": () => import("../components/NewDiscoveriesPage"),
  "recommended-playlists": () => import("../components/RecommendedPlaylistsPage"),
  "for-you": () => import("../components/ForYouPage"),
  "other-user-playlists": () => import("../components/OtherUserPlaylists"),

  premium: () => import("../components/Premium"),
  "upgrade-plans": () => import("../components/UpgradePlans"),
  "payment-processing": () => import("../components/PaymentProcessing"),
  "payment-success": () => import("../components/PaymentSuccess"),

  login: () => import("../components/Login"),
  register: () => import("../components/Register"),
  verify: () => import("../components/Verify"),
  "forgot-password": () => import("../components/ForgotPassword"),
};

const componentCache = new Map<string, ElementType<any>>();
const pendingLoads = new Map<string, Promise<ElementType<any> | null>>();

export const isNativeScreenReady = (page: string): boolean =>
  componentCache.has(page);

export const getNativeScreenComponent = (
  page: string,
): ElementType<any> | null => componentCache.get(page) ?? null;

/**
 * Load exactly one native route and cache the resolved component.
 * Web/PWA calls are a no-op so the existing Next.js dynamic-router behavior is
 * completely unchanged outside Capacitor.
 */
export const prepareNativeScreen = (
  page: string,
): Promise<ElementType<any> | null> => {
  if (typeof window === "undefined" || !Capacitor.isNativePlatform()) {
    return Promise.resolve(null);
  }

  const cached = componentCache.get(page);
  if (cached) return Promise.resolve(cached);

  const pending = pendingLoads.get(page);
  if (pending) return pending;

  const loader = screenLoaders[page];
  if (!loader) return Promise.resolve(null);

  const promise = loader()
    .then((module) => {
      const component = module.default;
      componentCache.set(page, component);
      pendingLoads.delete(page);
      return component;
    })
    .catch((error) => {
      pendingLoads.delete(page);
      throw error;
    });

  pendingLoads.set(page, promise);
  return promise;
};
