"use client";

import React, {
  useState,
  useEffect,
  useMemo,
  memo,
  useCallback,
  useRef,
} from "react";
import Image from "next/image";
import { SongOptionsDrawer } from "./SongOptionsDrawer";
import PlaylistOptionsDrawer from "./PlaylistOptionsDrawer";
import { useNavigation } from "./NavigationContext";
import { useAuth } from "./AuthContext";
import { useGuestAccess } from "./GuestAccessContext";
import { usePlayer, Track } from "./PlayerContext";
import ImageWithPlaceholder from "./ImageWithPlaceholder";
import { toast } from "react-hot-toast";
import { getFullShareUrl, slugify } from "../utils/share";
import { SEO } from "./SEO";
import { buildUserNavigationParams } from "../lib/userProfileRoute";

// ============== API INTERFACES ==============

interface ApiSong {
  id: number;
  title: string;
  artist_id?: number;
  artist_name: string;
  album_title?: string;
  cover_image: string;
  stream_url: string;
  duration_seconds: number;
  is_liked: boolean;
  genre_names?: string[];
  tag_names?: string[];
  mood_names?: string[];
  sub_genre_names?: string[];
  play_count?: number;
}

interface PlaylistResponse {
  id: number;
  unique_id?: string;
  title: string;
  description: string;
  cover_image?: string;
  covers?: string[];
  created_at: string;
  created_by?: string;
  songs: ApiSong[];
  song_ids?: number[];
  is_liked?: boolean;
  likes_count?: number;
  generated_by?: "system" | "admin" | "audience";
  creator_unique_id?: string | null;
}

// ============== HELPERS ==============

const formatDuration = (seconds: number): string => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, "0")}`;
};

const apiSongToTrack = (song: ApiSong): Track => ({
  id: String(song.id),
  title: song.title,
  artist: song.artist_name,
  artistId: song.artist_id,
  image: song.cover_image || "/default-cover.jpg",
  duration: formatDuration(song.duration_seconds),
  durationSeconds: song.duration_seconds,
  src: song.stream_url ? song.stream_url.replace("http://", "https://") : "",
  isLiked: song.is_liked,
});

// ============== SVG ICON COMPONENT ==============

type IconName =
  | "play"
  | "pause"
  | "heart"
  | "shuffle"
  | "more"
  | "arrowLeft"
  | "clock"
  | "music"
  | "shareNetwork"
  | "verified";

const ICON_PATHS: Record<
  IconName,
  { d: string; fill?: boolean; stroke?: boolean }
> = {
  play: { d: "M8 5.14v14l11-7-11-7z", fill: true },
  pause: { d: "M6 4h4v16H6V4zm8 0h4v16h-4V4z", fill: true },
  heart: {
    d: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z",
    stroke: true,
  },
  shuffle: {
    d: "M16 3l5 0 0 5M4 20L21 3M21 16l0 5-5 0M15 15l6 6M4 4l5 5",
    stroke: true,
  },
  more: {
    d: "M12 6m-2 0a2 2 0 1 0 4 0 2 2 0 1 0-4 0M12 12m-2 0a2 2 0 1 0 4 0 2 2 0 1 0-4 0M12 18m-2 0a2 2 0 1 0 4 0 2 2 0 1 0-4 0",
    fill: true,
  },
  arrowLeft: {
    d: "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",
    stroke: true,
  },
  clock: {
    d: "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z",
    stroke: true,
  },
  music: {
    d: "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z",
    fill: true,
  },
  shareNetwork: {
    d: "M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z",
    fill: true,
  },
  verified: {
    d: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-1 14l-4-4 1.41-1.41L11 13.17l5.59-5.59L18 9l-7 7z",
    fill: true,
  },
};

const Icon = memo(
  ({
    name,
    size = 24,
    filled,
    className = "",
  }: {
    name: IconName;
    size?: number;
    filled?: boolean;
    className?: string;
  }) => {
    const pathInfo = ICON_PATHS[name];
    if (!pathInfo) return null;
    const { d, fill, stroke } = pathInfo;
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        className={className}
        fill={fill || (name === "heart" && filled) ? "currentColor" : "none"}
        stroke={stroke ? "currentColor" : undefined}
        strokeWidth={stroke ? 2 : undefined}
        strokeLinecap={stroke ? "round" : undefined}
        strokeLinejoin={stroke ? "round" : undefined}
      >
        <path d={d} />
      </svg>
    );
  },
);
Icon.displayName = "Icon";

// ============== EQUALIZER ==============

const Equalizer = () => (
  <div className="flex items-end gap-0.5 h-3.5">
    {[0, 0.2, 0.4, 0.6].map((d, i) => (
      <span
        key={i}
        className="w-[3px] bg-green-500 rounded-sm animate-equalizer"
        style={{ animationDelay: `${d}s` }}
      />
    ))}
  </div>
);

// ============== HOOK: scroll tracking (like ArtistDetail) ==============

// ============== SONG ROW ==============

const SongRow = memo(
  ({
    song,
    idx,
    current,
    playing,
    onPlay,
    onMore,
    onTitleClick,
    onArtistClick,
  }: {
    song: ApiSong;
    idx: number;
    current: boolean;
    playing: boolean;
    onPlay: () => void;
    onMore: (song: ApiSong) => void;
    onTitleClick?: () => void;
    onArtistClick?: () => void;
  }) => {
    const [hover, setHover] = useState(false);

    const isDesktop =
      typeof window !== "undefined" &&
      window.matchMedia &&
      window.matchMedia("(min-width: 768px)").matches;

    return (
      <div
        onClick={onPlay}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
        className="flex items-center gap-4 py-2 pl-6 pr-2 sm:px-0 -mx-6 sm:mx-0 rounded-md cursor-pointer transition-all duration-300 hover:bg-white/[0.08] active:bg-white/[0.12] bg-black/5"
      >
        <div className="sb-song-index-gutter w-5 shrink-0 text-center text-sm text-neutral-400 tabular-nums">
          {hover ? (
            <Icon name={current && playing ? "pause" : "play"} size={14} />
          ) : current && playing ? (
            <Equalizer />
          ) : (
            <span className={current ? "text-green-500" : ""}>{idx + 1}</span>
          )}
        </div>

        <div className="w-11 h-11 shrink-0 overflow-hidden rounded relative">
          <ImageWithPlaceholder
            src={song.cover_image}
            alt={song.title}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="flex-1 min-w-0">
          {isDesktop && (onTitleClick || onArtistClick) ? (
            <>
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  onTitleClick && onTitleClick();
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.stopPropagation();
                    onTitleClick && onTitleClick();
                  }
                }}
                role={onTitleClick ? "link" : undefined}
                tabIndex={onTitleClick ? 0 : undefined}
                className={`text-[15px] font-medium truncate ${
                  current ? "text-green-500" : "text-white"
                } ${onTitleClick ? "cursor-pointer hover:underline" : ""}`}
              >
                {song.title}
              </div>
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  onArtistClick && onArtistClick();
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.stopPropagation();
                    onArtistClick && onArtistClick();
                  }
                }}
                role={onArtistClick ? "link" : undefined}
                tabIndex={onArtistClick ? 0 : undefined}
                className="text-[13px] text-white/60 truncate mt-0.5 cursor-pointer hover:underline"
              >
                {song.artist_name}
              </div>
            </>
          ) : (
            <>
              <div
                className={`text-[15px] font-medium truncate ${
                  current ? "text-green-500" : "text-white"
                }`}
              >
                {song.title}
              </div>
              <div className="text-[13px] text-white/60 truncate mt-0.5">
                {song.artist_name}
              </div>
            </>
          )}
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden sm:block text-[13px] text-neutral-400">
            {formatDuration(song.duration_seconds)}
          </div>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onMore(song);
            }}
            className="w-8 h-8 flex items-center justify-center text-white/40 hover:text-white"
          >
            <Icon name="more" size={18} />
          </button>
        </div>
      </div>
    );
  },
);
SongRow.displayName = "SongRow";

// ============== PLAYLIST DETAIL ==============

interface PlaylistDetailProps {
  id?: number | string;
  slug?: string;
  generatedBy?: "system" | "admin" | "audience";
  creatorUniqueId?: string | null;
  initialPlaylist?: PlaylistResponse | null;
}

const PlaylistDetail: React.FC<PlaylistDetailProps> = ({
  id,
  slug,
  generatedBy,
  creatorUniqueId,
  initialPlaylist,
}) => {
  const { goBack, scrollY, navigateTo, currentParams } = useNavigation();
  const { accessToken, authenticatedFetch, formatErrorMessage } = useAuth();
  const { requestAuth } = useGuestAccess();
  const { setQueue, currentTrack, isPlaying } = usePlayer();

  const hasHydratedInitialPlaylist = Boolean(
    initialPlaylist &&
      String(initialPlaylist.id) === String(id) &&
      Array.isArray(initialPlaylist.songs),
  );
  const [playlist, setPlaylist] = useState<PlaylistResponse | null>(
    hasHydratedInitialPlaylist ? initialPlaylist || null : null,
  );
  const [loading, setLoading] = useState(!hasHydratedInitialPlaylist);
  const [isLiked, setIsLiked] = useState(false);
  const [isLiking, setIsLiking] = useState(false);

  const [selectedSong, setSelectedSong] = useState<any | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isPlaylistDrawerOpen, setIsPlaylistDrawerOpen] = useState(false);

  const headerOpacity = useMemo(() => Math.min(scrollY / 300, 1), [scrollY]);
  const showHeader = scrollY > 50;

  const fetchPlaylist = useCallback(async () => {
    if (!id) return;

    // Use the recommendation endpoint if the ID is not purely numeric (like smart_rec_ or liked_rec_)
    const isRecommended = typeof id === "string" && !/^\d+$/.test(id);

    setLoading(true);
    try {
      const url = isRecommended
        ? `https://api.sedabox.com/api/home/playlist-recommendations/${id}/`
        : `https://api.sedabox.com/api/playlists/${id}/`;

      const resp = await authenticatedFetch(url);
      if (resp.ok) {
        const data = await resp.json();
        // Fallback to props if generated_by is missing from API response
        if (generatedBy && !data.generated_by) {
          data.generated_by = generatedBy;
        }
        if (creatorUniqueId && !data.creator_unique_id) {
          data.creator_unique_id = creatorUniqueId;
        }
        setPlaylist(data);
        setIsLiked(!!data.is_liked);

        // Fix URL if slug is missing or does not match
        // Only if not a recommendation
        if (!isRecommended && data && data.title) {
          const hasSlug =
            currentParams?.title ||
            slug ||
            (typeof window !== "undefined" &&
              window.location.pathname.includes(`-${slugify(data.title)}`));

          if (!hasSlug) {
            navigateTo(
              "playlist-detail",
              {
                ...currentParams,
                id: data.id,
                title: data.title,
                slug: slugify(data.title),
              },
              "replace",
            );
          }
        }
      } else {
        toast.error("خطا در بارگذاری پلی‌لیست");
      }
    } catch (err) {
      console.error("Fetch playlist error:", err);
      toast.error("خطای شبکه");
    } finally {
      setLoading(false);
    }
  }, [
    id,
    authenticatedFetch,
    generatedBy,
    creatorUniqueId,
    slug,
    currentParams,
    navigateTo,
  ]);

  useEffect(() => {
    if (hasHydratedInitialPlaylist && initialPlaylist) {
      setPlaylist(initialPlaylist);
      setIsLiked(!!initialPlaylist.is_liked);
      setLoading(false);
      return;
    }
    fetchPlaylist();
  }, [fetchPlaylist, hasHydratedInitialPlaylist, initialPlaylist]);

  useEffect(() => {
    const handleSongLikeChanged = (e: any) => {
      const { id: songId, liked } = e.detail;
      setPlaylist((prev) => {
        if (!prev) return prev;
        return {
          ...prev,
          songs: prev.songs.map((s) =>
            String(s.id) === String(songId) ? { ...s, is_liked: !!liked } : s,
          ),
        };
      });
    };

    window.addEventListener("song-like-changed" as any, handleSongLikeChanged);
    return () =>
      window.removeEventListener(
        "song-like-changed" as any,
        handleSongLikeChanged,
      );
  }, []);

  const handleToggleLike = async () => {
    if (!playlist) return;
    if (!accessToken) {
      requestAuth("برای لایک‌کردن و ذخیره این پلی‌لیست وارد شوید.");
      return;
    }
    setIsLiking(true);
    try {
      // Use the recommendation like endpoint when this is a recommended playlist
      // Check if unique_id is mixed (has letters)
      const uniqueIdStr = String(playlist.unique_id || playlist.id);
      const isRecommended = !/^\d+$/.test(uniqueIdStr);

      const likeUrl = isRecommended
        ? `https://api.sedabox.com/api/home/playlist-recommendations/${uniqueIdStr}/like/`
        : `https://api.sedabox.com/api/playlists/${playlist.id}/like/`;

      const resp = await authenticatedFetch(likeUrl, { method: "POST" });
      if (resp.ok) {
        const data = await resp.json();
        // Normalize liked value from possible response shapes
        const rawLiked =
          typeof data.liked !== "undefined"
            ? data.liked
            : typeof data.is_liked !== "undefined"
              ? data.is_liked
              : undefined;
        const parseBool = (v: any) => {
          if (typeof v === "boolean") return v;
          if (typeof v === "number") return v === 1;
          if (typeof v === "string") return v === "1" || v === "true";
          return undefined;
        };
        const liked =
          typeof rawLiked !== "undefined" ? parseBool(rawLiked) : !isLiked;

        setIsLiked(Boolean(liked));
        if (playlist) {
          setPlaylist({
            ...playlist,
            likes_count:
              typeof data.likes_count !== "undefined"
                ? data.likes_count
                : playlist.likes_count,
            is_liked: Boolean(liked),
          });
        }
        toast.success(liked ? "پلی‌لیست لایک شد" : "لایک حذف شد");
      } else if (resp.status !== 401) {
        const body = await resp.json().catch(() => null);
        toast.error(formatErrorMessage(body));
      }
    } catch (err) {
      console.error("Like error:", err);
      toast.error("خطای شبکه");
    } finally {
      setIsLiking(false);
    }
  };

  const handleMore = useCallback((song: ApiSong) => {
    setSelectedSong(song);
    setIsDrawerOpen(true);
  }, []);

  const handleShare = async () => {
    if (!playlist) return;
    try {
      const uniqueIdStr = String(playlist.unique_id || playlist.id);
      const useUniqueId = !!playlist.unique_id && !/^\d+$/.test(uniqueIdStr);
      const idForShare = useUniqueId ? playlist.unique_id! : playlist.id;
      const url = getFullShareUrl("playlist", idForShare, playlist.title);
      if (typeof navigator !== "undefined" && navigator.share) {
        await navigator.share({
          title: playlist.title,
          text: `گوش دادن به این لیست پخش در سداباکس`,
          url: url,
        });
      } else if (typeof navigator !== "undefined" && navigator.clipboard) {
        await navigator.clipboard.writeText(url);
        toast.success("لینک کپی شد");
      }
    } catch (err) {
      console.error("Playlist share failed:", err);
    }
  };

  const handleAction = useCallback(
    async (action: string, song: any) => {
      if (action === "share" && song) {
        try {
          const url = getFullShareUrl("song", song.id, song.title);
          const text = `گوش دادن به آهنگ ${song.title} از ${song.artist_name} در سداباکس`;
          if (typeof navigator !== "undefined" && navigator.share) {
            await navigator.share({ title: song.title, text, url });
          } else {
            await navigator.clipboard.writeText(url);
            toast.success("لینک کپی شد");
          }
        } catch (err) {
          console.error("Song share failed:", err);
        }
      }
      if (action === "toggle-like" && song) {
        if (!accessToken) {
          requestAuth("برای لایک‌کردن آهنگ وارد شوید.");
          return;
        }
        try {
          const url = `https://api.sedabox.com/api/songs/${song.id}/like/`;
          const resp = await authenticatedFetch(url, { method: "POST" });
          if (resp.ok) {
            const data = await resp.json();
            return data;
          }
        } catch (err) {
          console.error("Song like failed:", err);
        }
      }
    },
    [accessToken, authenticatedFetch, requestAuth],
  );

  const handlePlaySong = (idx: number) => {
    if (!playlist) return;
    const tracks = playlist.songs.map(apiSongToTrack);
    setQueue(tracks, idx);
  };

  const handlePlayAll = () => {
    if (!playlist || playlist.songs.length === 0) return;
    const tracks = playlist.songs.map(apiSongToTrack);
    setQueue(tracks, 0);
  };

  const totalDuration = useMemo(() => {
    if (!playlist) return "0:00";
    const totalSecs = playlist.songs.reduce(
      (sum, s) => sum + s.duration_seconds,
      0,
    );
    const hours = Math.floor(totalSecs / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    if (hours > 0) return `${hours} ساعت و ${mins} دقیقه`;
    return `${mins} دقیقه`;
  }, [playlist]);

  const PlaylistSkeleton = memo(() => (
    <div
      className="min-h-screen bg-[#0a0a0a] text-white animate-pulse"
    >
      <div className="relative w-full h-96 md:h-[500px] bg-zinc-900 mb-6" />

      <div className="px-6 md:px-12 py-6">
        <div className="flex items-center gap-6 mb-6">
          <div className="w-16 h-16 rounded-full bg-zinc-800" />
          <div className="flex-1">
            <div className="h-5 bg-zinc-800 rounded w-3/4 mb-3" />
            <div className="h-4 bg-zinc-800 rounded w-1/2" />
          </div>
          <div className="w-12 h-12 bg-zinc-800 rounded-full" />
        </div>

        <div className="space-y-3">
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className="flex items-center gap-4 py-3 px-2 rounded-md bg-transparent"
            >
              <div className="w-6 text-center text-sm text-neutral-400 tabular-nums">
                <div className="h-4 w-4 bg-zinc-800 rounded mx-auto" />
              </div>
              <div className="w-11 h-11 shrink-0 overflow-hidden rounded bg-zinc-800" />
              <div className="flex-1 min-w-0">
                <div className="h-4 bg-zinc-800 rounded w-3/4 mb-2" />
                <div className="h-3 bg-zinc-800 rounded w-1/3" />
              </div>
              <div className="hidden sm:block w-12">
                <div className="h-4 bg-zinc-800 rounded w-12 ml-auto" />
              </div>
              <div className="w-8" />
            </div>
          ))}
        </div>
      </div>
    </div>
  ));

  if (loading) return <PlaylistSkeleton />;

  if (!playlist) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-6 text-center">
        <SEO title="پلی‌لیست یافت نشد" />
        <Icon name="music" size={64} className="text-neutral-700 mb-4" />
        <h2 className="text-2xl font-bold mb-2">پلی‌لیست یافت نشد</h2>
        <button
          type="button"
          onClick={goBack}
          className="mt-4 px-6 py-2 bg-green-500 text-black rounded-full font-bold"
        >
          بازگشت
        </button>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-linear-to-b from-neutral-900 via-neutral-950 to-black text-white pb-24"
    >
      <SEO
        title={playlist.title}
        description={`گوش دادن به پلی‌لیست ${playlist.title} در وب اپلیکیشن صداباکس - شامل ${playlist.songs.length} آهنگ`}
        imageUrl={playlist.cover_image}
        type="music.playlist"
      />
      {/* Desktop glass header (appears on scroll) */}
      <header
        className="hidden md:flex sticky top-0 z-50 h-16 items-center justify-between px-6 bg-zinc-900/80 backdrop-blur-xl"
        style={{ backgroundColor: `rgba(17,17,17,${headerOpacity})` }}
      >
        <div className="flex items-center gap-3"></div>
        <div className="flex-1 text-center">
          <div className="text-sm text-white font-semibold truncate max-w-lg mx-auto">
            {playlist.title}
          </div>
        </div>
        <div className="flex items-center gap-3" />
      </header>

      {/* Mobile condensed header that slides in when scrolled */}
      <header
        className="md:hidden fixed flex-row-reverse top-0 inset-x-0 h-16 bg-black/20 backdrop-blur-xl flex items-center justify-between px-4 z-50 transition-all duration-250"
        style={{
          transform: showHeader ? "translateY(0)" : "translateY(-100%)",
          opacity: showHeader ? 1 : 0,
        }}
      >
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={goBack}
            className="w-10 h-10 rounded-full bg-black/30 hover:bg-black/50 flex items-center justify-center transition-all"
          >
            <Icon name="arrowLeft" className="w-5 h-5 text-white sb-back-icon" />
          </button>
        </div>
        <div className="flex-1 text-center">
          <div className="text-sm text-white font-semibold truncate max-w-xs mx-auto">
            {playlist.title}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handlePlayAll}
            className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center shadow-md"
          >
            <Icon name="play" className="w-4 h-4 text-black ml-0.5" />
          </button>
        </div>
      </header>
      <header
        className="relative w-full h-96 md:h-[500px] bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0.6) 50%, rgba(0,0,0,0.8) 100%), url(${
            playlist.cover_image ||
            (playlist.covers && playlist.covers[0]) ||
            (playlist.songs && playlist.songs.length > 0
              ? playlist.songs[0].cover_image
              : "") ||
            "/default-cover.jpg"
          })`,
        }}
      >
        <div className="absolute top-4 left-4 z-20 sb-back-position">
          <button
            type="button"
            onClick={goBack}
            className="w-12 h-12 rounded-full bg-black/50 hover:bg-black/70 flex items-center justify-center transition-all duration-300 hover:scale-105"
          >
            <Icon name="arrowLeft" className="w-6 h-6 text-white sb-back-icon" />
          </button>
        </div>

        <div className="sb-playlist-hero-info absolute inset-y-0 flex items-end pb-8">
          <div className="text-start max-w-lg">
            <p className="text-sm font-semibold text-green-400 mb-2 uppercase tracking-wide">
              پلی‌لیست
            </p>
            <h1 className="text-4xl md:text-6xl lg:text-8xl font-black mb-4 text-white drop-shadow-lg">
              {playlist.title}
            </h1>
            <p className="text-neutral-200 text-base md:text-lg mb-6 leading-relaxed">
              {playlist.description}
            </p>
            <div className="flex items-center gap-3 text-sm text-neutral-300">
              {playlist.likes_count !== undefined && (
                <>
                  <span className="text-white font-bold">
                    {playlist.likes_count}
                  </span>
                  <span>لایک</span>
                  <span>•</span>
                </>
              )}
              <span>{playlist.songs.length} آهنگ</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Icon name="clock" className="w-4 h-4" />
                {totalDuration}
              </span>
            </div>
            {(playlist.generated_by === "system" ||
              playlist.generated_by === "admin") && (
              <button
                type="button"
                onClick={() => navigateTo("user-detail", buildUserNavigationParams({ unique_id: "sedabox", is_official: true }))}
                className="mt-3 text-sm text-green-400 transition-colors text-start flex items-center gap-2"
              >
                <span className="hover:underline cursor-pointer">صداباکس</span>
                <Icon name="verified" className="w-4 h-4 text-green-400" />
              </button>
            )}
            {playlist.generated_by === "audience" &&
              playlist.creator_unique_id && (
                <button
                  type="button"
                  onClick={() =>
                    navigateTo(
                      "user-detail",
                      buildUserNavigationParams({
                        unique_id: playlist.creator_unique_id!,
                      }),
                    )
                  }
                  className="mt-3 text-sm text-blue-400 hover:underline transition-colors text-start"
                >
                  <span className="cursor-pointer">
                    {playlist.creator_unique_id}
                  </span>
                </button>
              )}
          </div>
        </div>
      </header>

      <div className="sticky top-0 z-30 bg-linear-to-b from-neutral-950/95 to-neutral-950 px-6 md:px-12 py-4 border-b border-white/10">
        <div className="flex items-center gap-6">
          <button
            type="button"
            onClick={handlePlayAll}
            className="w-14 h-14 rounded-full bg-green-500 hover:bg-green-400 hover:scale-110 flex items-center justify-center shadow-2xl transition-all duration-300"
          >
            <Icon name="play" className="w-7 h-7 text-black ml-1" />
          </button>

          <button
            type="button"
            onClick={handleToggleLike}
            disabled={isLiking}
            className={`w-12 h-12 rounded-full hover:bg-white/10 flex items-center justify-center transition-colors duration-200 ${
              isLiked ? "text-green-500" : "text-neutral-400 hover:text-white"
            }`}
          >
            {isLiking ? (
              <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
            ) : (
              <Icon name="heart" className="w-7 h-7" filled={isLiked} />
            )}
          </button>

          <button
            type="button"
            onClick={handleShare}
            className="w-12 h-12 rounded-full hover:bg-white/10 flex items-center justify-center text-neutral-400 hover:text-white transition-colors duration-200"
          >
            <Icon name="shareNetwork" className="w-7 h-7" />
          </button>

          <button
            type="button"
            className="w-12 h-12 rounded-full hover:bg-white/10 flex items-center justify-center text-neutral-400 hover:text-white transition-colors duration-200"
            onClick={() => setIsPlaylistDrawerOpen(true)}
          >
            <Icon name="more" className="w-7 h-7" />
          </button>
        </div>
      </div>

      <main className="px-6 md:px-12 mt-4 space-y-1">
        {playlist.songs.map((song, index) => (
          <SongRow
            key={song.id}
            song={song}
            idx={index}
            current={String(song.id) === currentTrack?.id}
            playing={isPlaying}
            onPlay={() => handlePlaySong(index)}
            onMore={handleMore}
            onTitleClick={() =>
              navigateTo("song-detail", {
                id: song.id,
                title: slugify(song.title),
              })
            }
            onArtistClick={() =>
              song.artist_id &&
              navigateTo("artist-detail", { id: song.artist_id })
            }
          />
        ))}
      </main>

      <SongOptionsDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        song={selectedSong}
        onAction={handleAction}
      />

      <PlaylistOptionsDrawer
        isOpen={isPlaylistDrawerOpen}
        onClose={() => setIsPlaylistDrawerOpen(false)}
        playlist={playlist}
        onAction={(action) => {
          if (action === "toggle-like") return handleToggleLike();
          if (action === "share") return handleShare();
          return undefined;
        }}
      />

      <style jsx global>{`
        @keyframes equalizer {
          0% {
            height: 4px;
          }
          50% {
            height: 14px;
          }
          100% {
            height: 4px;
          }
        }
        .animate-equalizer {
          animation: equalizer 0.6s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default PlaylistDetail;
