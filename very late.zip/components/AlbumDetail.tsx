"use client";

import React, { useState, useMemo, useCallback, useEffect, useRef } from "react";
import Image from "next/image";
import { replaceCurrentNavigationEntry, useNavigation } from "./NavigationContext";
import { useAuth } from "./AuthContext";
import { useGuestAccess } from "./GuestAccessContext";
import { usePlayerPlayback, Track } from "./PlayerContext";
import { SongOptionsDrawer } from "./SongOptionsDrawer";
import { getFullShareUrl } from "../utils/share";
import { getCanonicalSlug } from "../lib/slug";
import toast from "react-hot-toast";
import { SEO } from "./SEO";
import { getPlayerFeaturedArtists, getSongDisplayTitle, normalizeSongCollection } from "../lib/songDisplay";
import SongTitleWithFeaturedArtists from "./SongTitleWithFeaturedArtists";
import { deleteRouteDataCache, makeRouteDataCacheKey, readRouteDataCache, writeRouteDataCache } from "../lib/routeDataCache";

// API Interfaces based on the provided format
interface ApiSong {
  id: number;
  title: string;
  title_en?: string;
  url_slug?: string;
  artist_url_slug?: string;
  display_title?: string;
  artist_id: number;
  artist_name: string;
  featured_artists: any[];
  album: number;
  album_title: string;
  is_single: boolean;
  stream_url: string;
  cover_image: string;
  duration_seconds: number;
  duration_display: string;
  plays: number;
  likes_count: number;
  songs_count?: number;
  is_liked: boolean;
  status: string;
  release_date: string | null;
  language: string;
  description: string;
  created_at: string;
}

interface ApiAlbumResponse {
  id: number;
  title: string;
  title_en?: string;
  url_slug?: string;
  artist_id: number;
  artist_name: string;
  artist_unique_id?: string;
  artist_url_slug?: string;
  cover_image: string;
  release_date: string | null;
  description: string;
  created_at: string;
  likes_count: number;
  is_liked: boolean;
  genre_ids: number[];
  sub_genre_ids: number[];
  mood_ids: number[];
  songs: ApiSong[];
  song_genre_names: string[];
  song_mood_names: string[];
}

// Reuse the same icons and helpers from the page version
const SvgIcon = ({
  d,
  className,
  fill = "currentColor",
  strokeWidth = 0,
}: {
  d: string;
  className?: string;
  fill?: string;
  strokeWidth?: number;
}) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill={fill === "none" ? "none" : fill}
    stroke={fill === "none" ? "currentColor" : "none"}
    strokeWidth={strokeWidth}
  >
    <path d={d} />
  </svg>
);

const ICON_PATHS = {
  play: "M8 5v14l11-7z",
  pause: "M6 19h4V5H6v14zm8-14v14h4V5h-4z",
  heart:
    "M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z",
  clock:
    "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z",
  music:
    "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z",
  shuffle:
    "M10.59 9.17L5.41 4 4 5.41l5.17 5.17 1.42-1.41zM14.5 4l2.04 2.04L4 18.59 5.41 20 17.96 7.46 20 9.5V4h-5.5zm.33 9.41l-1.41 1.41 3.13 3.13L14.5 20H20v-5.5l-2.04 2.04-3.13-3.13z",
  arrowLeft: "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",
  shareNetwork:
    "M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z",
  dotsThree:
    "M6 10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z",
};

const Icon = ({
  name,
  className,
  fill = true,
}: {
  name: keyof typeof ICON_PATHS;
  className?: string;
  fill?: boolean;
}) => (
  <SvgIcon
    d={ICON_PATHS[name]}
    className={className}
    fill={fill ? "currentColor" : "none"}
    strokeWidth={fill ? 0 : 2}
  />
);

// Album slug lookup removed — AlbumDetail fetches by numeric ID from the API.

interface SongRowProps {
  song: ApiSong;
  index: number;
  isPlaying?: boolean;
  onPlay?: () => void;
  onMore: (song: ApiSong) => void;
  onTitleClick?: () => void;
  onArtistClick?: () => void;
}

const SongRow: React.FC<SongRowProps> = ({
  song,
  index,
  isPlaying = false,
  onPlay,
  onMore,
  onTitleClick,
  onArtistClick,
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isLiked, setIsLiked] = useState(song.is_liked);

  const isDesktop =
    typeof window !== "undefined" &&
    window.matchMedia &&
    window.matchMedia("(min-width: 768px)").matches;

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onPlay}
      className={`group grid grid-cols-[16px_4fr_minmax(80px,1fr)] md:grid-cols-[16px_4fr_2fr_minmax(80px,1fr)] gap-4 px-1 py-2 rounded-md transition-colors cursor-pointer ${
        isPlaying
          ? "bg-white/10"
          : isHovered
            ? "bg-white/5"
            : "hover:bg-white/5"
      }`}
    >
      <div className="flex items-center justify-center w-4">
        {isHovered ? (
          <button className="text-white">
            {isPlaying ? (
              <Icon name="pause" className="w-3.5 h-3.5" />
            ) : (
              <Icon name="play" className="w-3.5 h-3.5" />
            )}
          </button>
        ) : isPlaying ? (
          <Icon name="music" className="w-3.5 h-3.5 text-green-500" />
        ) : (
          <span className="text-sm text-neutral-400">{index + 1}</span>
        )}
      </div>

      <div className="flex items-center gap-3 min-w-0">
        <div className="relative w-10 h-10 shrink-0 rounded overflow-hidden bg-neutral-800">
          <Image
            src={song.cover_image || "/default-cover.jpg"}
            alt={getSongDisplayTitle(song)}
            fill
            sizes="40px"
            quality={75}
            className="object-cover"
          />
        </div>
        <div className="min-w-0 flex-1">
          {isDesktop && (onTitleClick || onArtistClick) ? (
            <>
              <p
                onClick={(e) => {
                  e.stopPropagation();
                  onTitleClick && onTitleClick();
                }}
                className={`w-fit max-w-full text-sm font-medium truncate ${
                  isPlaying ? "text-green-500" : "text-white"
                } ${onTitleClick ? "cursor-pointer hover:underline" : ""}`}
              >
                <SongTitleWithFeaturedArtists song={song} />
              </p>
              <p
                onClick={(e) => {
                  e.stopPropagation();
                  onArtistClick && onArtistClick();
                }}
                className="w-fit max-w-full text-xs text-neutral-400 truncate flex items-center gap-1 cursor-pointer hover:underline"
              >
                {song.artist_name}
              </p>
            </>
          ) : (
            <>
              <p
                className={`w-fit max-w-full text-sm font-medium truncate ${
                  isPlaying ? "text-green-500" : "text-white"
                }`}
              >
                <SongTitleWithFeaturedArtists song={song} />
              </p>
              <p className="text-xs text-neutral-400 truncate flex items-center gap-1">
                {song.artist_name}
              </p>
            </>
          )}
        </div>
      </div>

      <div className="hidden md:flex items-center">
        <p className="text-sm text-neutral-400">۱ هفته پیش</p>
      </div>

      <div className="flex items-center justify-end gap-3">
        <button
          onClick={(e) => {
            e.stopPropagation();
            setIsLiked(!isLiked);
          }}
          className={`opacity-0 group-hover:opacity-100 transition-opacity ${
            isLiked ? "opacity-100" : ""
          }`}
        >
          <Icon
            name="heart"
            className={`w-4 h-4 ${
              isLiked ? "text-green-500" : "text-neutral-400 hover:text-white"
            }`}
            fill={isLiked}
          />
        </button>
        <span className="text-sm text-neutral-400">
          {song.duration_display}
        </span>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onMore(song);
          }}
          className="opacity-0 group-hover:opacity-100 transition-opacity text-neutral-400 hover:text-white"
        >
          <Icon name="dotsThree" className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

const AlbumSkeleton = () => (
  <div className="min-h-screen bg-[#0a0a0a] text-white animate-pulse">
    {/* Hero Skeleton */}
    <div className="relative h-96 md:h-[500px] bg-zinc-900" />

    {/* Actions Skeleton */}
    <div className="flex items-center gap-6 px-6 md:px-12 py-6">
      <div className="w-16 h-16 bg-zinc-800 rounded-full" />
      <div className="w-12 h-12 bg-zinc-800 rounded-full" />
      <div className="w-12 h-12 bg-zinc-800 rounded-full" />
      <div className="w-12 h-12 bg-zinc-800 rounded-full" />
    </div>

    {/* Content Skeleton */}
    <div className="px-6 md:px-12 space-y-4">
      <div className="h-10 border-b border-white/10 flex items-center gap-4 px-4">
        <div className="w-4 h-4 bg-zinc-800 rounded" />
        <div className="w-1/4 h-4 bg-zinc-800 rounded" />
        <div className="w-1/4 h-4 bg-zinc-800 rounded ml-auto" />
      </div>
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div key={i} className="flex items-center gap-4 px-4 py-2">
          <div className="w-4 h-4 bg-zinc-800 rounded" />
          <div className="w-10 h-10 bg-zinc-800 rounded" />
          <div className="flex-1 space-y-2">
            <div className="w-1/3 h-4 bg-zinc-800 rounded" />
            <div className="w-1/4 h-3 bg-zinc-800 rounded" />
          </div>
          <div className="w-12 h-4 bg-zinc-800 rounded" />
        </div>
      ))}
    </div>
  </div>
);

const unwrapAlbumPayload = (value: any) =>
  value?.data?.album ?? value?.data ?? value?.album ?? value;

const hasCompleteAlbumPayload = (value: any) => {
  const payload = unwrapAlbumPayload(value);
  return Boolean(
    payload?.id &&
      Array.isArray(payload?.songs) &&
      Array.isArray(payload?.song_genre_names) &&
      Array.isArray(payload?.song_mood_names) &&
      Object.prototype.hasOwnProperty.call(payload, "is_liked") &&
      Object.prototype.hasOwnProperty.call(payload, "artist_id"),
  );
};

const normalizeAlbumPayload = (value: any): ApiAlbumResponse | null => {
  const payload = unwrapAlbumPayload(value);
  const id = Number(payload?.id);
  if (!Number.isFinite(id) || id <= 0) return null;

  return {
    ...payload,
    id,
    title: String(payload?.title || ""),
    artist_id: Number(payload?.artist_id || 0),
    artist_name: String(payload?.artist_name || ""),
    cover_image: String(payload?.cover_image || ""),
    release_date: payload?.release_date || null,
    description: String(payload?.description || ""),
    created_at: String(payload?.created_at || ""),
    likes_count: Number(payload?.likes_count || 0),
    songs_count: Number(
      payload?.songs_count ??
        (Array.isArray(payload?.songs) ? payload.songs.length : 0),
    ),
    is_liked: Boolean(payload?.is_liked),
    genre_ids: Array.isArray(payload?.genre_ids) ? payload.genre_ids : [],
    sub_genre_ids: Array.isArray(payload?.sub_genre_ids)
      ? payload.sub_genre_ids
      : [],
    mood_ids: Array.isArray(payload?.mood_ids) ? payload.mood_ids : [],
    songs: normalizeSongCollection<ApiSong>(payload?.songs).filter(
      (song) => Number(song?.id) > 0,
    ),
    song_genre_names: Array.isArray(payload?.song_genre_names)
      ? payload.song_genre_names
      : [],
    song_mood_names: Array.isArray(payload?.song_mood_names)
      ? payload.song_mood_names
      : [],
  } as ApiAlbumResponse;
};

interface AlbumDetailProps {
  id?: string | number;
  slug?: string;
  album?: any;
}

const AlbumDetail: React.FC<AlbumDetailProps> = ({
  id: idProp,
  slug,
  album: albumProp,
}) => {
  const { goBack, currentParams, navigateTo } = useNavigation();
  const { accessToken, authenticatedFetch, user } = useAuth();
  const authenticatedFetchRef = useRef(authenticatedFetch);
  authenticatedFetchRef.current = authenticatedFetch;
  const { requestAuth } = useGuestAccess();
  const { setQueue, currentTrack, isPlaying: isPlayerPlaying } = usePlayerPlayback();

  const albumId = idProp || currentParams?.id;
  const albumCacheKey = albumId
    ? makeRouteDataCacheKey("album", albumId, user?.id)
    : null;
  const currentParamsRef = useRef(currentParams);
  currentParamsRef.current = currentParams;
  const initialNavigationPayload = currentParams?.album ?? albumProp;
  const initialNavigationAlbum = normalizeAlbumPayload(initialNavigationPayload);
  const initialAlbum =
    initialNavigationAlbum &&
    String(initialNavigationAlbum.id) === String(albumId) &&
    hasCompleteAlbumPayload(initialNavigationPayload)
      ? initialNavigationAlbum
      : readRouteDataCache<ApiAlbumResponse>(albumCacheKey);

  const [albumData, setAlbumData] = useState<ApiAlbumResponse | null>(initialAlbum);
  const [loading, setLoading] = useState(!initialAlbum);
  const [isLiked, setIsLiked] = useState(Boolean(initialAlbum?.is_liked));
  const [liking, setLiking] = useState(false);

  const [selectedSong, setSelectedSong] = useState<any | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const albumSongs = useMemo(
    () => (Array.isArray(albumData?.songs) ? albumData.songs : []),
    [albumData],
  );

  useEffect(() => {
    let active = true;
    const controller = new AbortController();

    const fetchAlbum = async () => {
      if (!albumId) {
        if (active) {
          setAlbumData(null);
          setLoading(false);
        }
        return;
      }

      const navigationPayload = currentParamsRef.current?.album ?? albumProp;
      const navigationAlbum = normalizeAlbumPayload(navigationPayload);
      const navigationMatches =
        navigationAlbum && String(navigationAlbum.id) === String(albumId);

      // Only a genuine detail payload may bypass the detail endpoint. Card/list
      // payloads are intentionally partial and must never be treated as complete.
      if (navigationMatches && hasCompleteAlbumPayload(navigationPayload)) {
        writeRouteDataCache(albumCacheKey, navigationAlbum);
        if (active) {
          setAlbumData(navigationAlbum);
          setIsLiked(Boolean(navigationAlbum.is_liked));
          setLoading(false);
        }
        return;
      }

      const cached = readRouteDataCache<ApiAlbumResponse>(albumCacheKey);
      if (active && cached) {
        setAlbumData(cached);
        setIsLiked(Boolean(cached.is_liked));
        setLoading(false);
      } else if (active) {
        setLoading(true);
        setAlbumData((previous) =>
          previous && String(previous.id) === String(albumId) ? previous : null,
        );
      }

      try {
        const response = await authenticatedFetchRef.current(
          `https://api.sedabox.com/api/albums/${albumId}/`,
          { signal: controller.signal },
        );
        if (!response.ok) {
          deleteRouteDataCache(albumCacheKey);
          if (active) setAlbumData(null);
          throw new Error(`Album request failed with status ${response.status}`);
        }

        const data = normalizeAlbumPayload(await response.json());
        if (!data) throw new Error("Album response is malformed");
        if (!active) return;

        writeRouteDataCache(albumCacheKey, data);
        setAlbumData(data);
        setIsLiked(data.is_liked);

        const routeParams = currentParamsRef.current;
        const canonicalSlug = getCanonicalSlug(data);
        const targetPath = `/album/${data.id}${canonicalSlug ? `-${canonicalSlug}` : ""}`;
        if (typeof window !== "undefined" && window.location.pathname !== targetPath) {
          replaceCurrentNavigationEntry(
            "album-detail",
            {
              ...routeParams,
              id: data.id,
              urlSlug: canonicalSlug,
            },
            targetPath,
          );
        }
      } catch (error) {
        if (controller.signal.aborted || !active) return;
        console.error("Error fetching album:", error);
        if (!readRouteDataCache<ApiAlbumResponse>(albumCacheKey)) {
          setAlbumData(null);
        }
      } finally {
        if (active) setLoading(false);
      }
    };

    void fetchAlbum();
    return () => {
      active = false;
      controller.abort();
    };
  }, [albumCacheKey, albumId, albumProp]);


  const handleMore = useCallback((song: ApiSong) => {
    setSelectedSong(song);
    setIsDrawerOpen(true);
  }, []);

  const handleAction = async (action: string, s: any) => {
    if (action === "share" && s) {
      try {
        const url = getFullShareUrl("song", s.id, getCanonicalSlug(s));
        if (typeof navigator !== "undefined" && navigator.share) {
          await navigator.share({
            title: getSongDisplayTitle(s),
            text: `گوش دادن به آهنگ ${getSongDisplayTitle(s)} از ${s.artist_name || albumData?.artist_name} در سداباکس`,
            url: url,
          });
        } else {
          await navigator.clipboard.writeText(url);
          toast.success("لینک کپی شد");
        }
      } catch (err) {
        console.error("Song share failed:", err);
      }
    }
  };

  const handleShare = async () => {
    if (!albumData) return;
    try {
      const url = getFullShareUrl("album", albumData.id, getCanonicalSlug(albumData));
      if (typeof navigator !== "undefined" && navigator.share) {
        await navigator.share({
          title: albumData.title,
          text: `گوش دادن به آلبوم ${albumData.title} از ${albumData.artist_name} در سداباکس`,
          url: url,
        });
      } else if (typeof navigator !== "undefined" && navigator.clipboard) {
        await navigator.clipboard.writeText(url);
        toast.success("لینک کپی شد");
      }
    } catch (err) {
      console.error("Album share failed:", err);
    }
  };

  const handleLike = async () => {
    if (!albumData) return;
    if (!accessToken) {
      requestAuth("برای لایک‌کردن آلبوم و نگه‌داشتن آن در کتابخانه وارد شوید.");
      return;
    }

    setLiking(true);
    try {
      const response = await authenticatedFetch(
        `https://api.sedabox.com/api/albums/${albumData.id}/like/`,
        {
          method: "POST",
        },
      );
      if (response.ok) {
        const data = await response.json();
        setIsLiked(data.liked);
        setAlbumData((previous) => {
          if (!previous) return previous;
          const next = { ...previous, is_liked: Boolean(data.liked) };
          writeRouteDataCache(albumCacheKey, next);
          return next;
        });
        toast.success(data.liked ? "آلبوم لایک شد" : "لایک آلبوم لغو شد");
      } else {
        toast.error("خطا در لایک آلبوم");
      }
    } catch (error) {
      toast.error("خطا در اتصال");
    } finally {
      setLiking(false);
    }
  };

  const handlePlayAll = () => {
    if (!albumData || albumSongs.length === 0) return;

    const tracks: Track[] = albumSongs.map((song) => ({
      id: String(song.id),
      title: getSongDisplayTitle(song),
      artist: song.artist_name,
      featuredArtists: getPlayerFeaturedArtists(song),
      artistId: song.artist_id,
      image: song.cover_image,
      duration: song.duration_display,
      durationSeconds: song.duration_seconds,
      src: (song.stream_url || (song as any).preview_url || "").replace("http://", "https://"),
      isLiked: song.is_liked,
    }));

    setQueue(tracks, 0);
  };

  const handlePlaySong = (index: number) => {
    if (!albumData) return;

    const tracks: Track[] = albumSongs.map((song) => ({
      id: String(song.id),
      title: getSongDisplayTitle(song),
      artist: song.artist_name,
      featuredArtists: getPlayerFeaturedArtists(song),
      artistId: song.artist_id,
      image: song.cover_image,
      duration: song.duration_display,
      durationSeconds: song.duration_seconds,
      src: (song.stream_url || (song as any).preview_url || "").replace("http://", "https://"),
      isLiked: song.is_liked,
    }));

    setQueue(tracks, index);
  };

  if (loading) {
    return (
      <>
        <SEO title="در حال بارگذاری..." />
        <AlbumSkeleton />
      </>
    );
  }

  if (!albumData) {
    return (
      <div
        className="min-h-screen bg-linear-to-b from-neutral-900 to-neutral-950 text-white"
      >
        <SEO title="آلبوم پیدا نشد" />
        <div className="max-w-7xl mx-auto px-4 py-20">
          <div className="text-center">
            <Icon
              name="music"
              className="w-16 h-16 mx-auto text-neutral-600 mb-4"
            />
            <h1 className="text-2xl font-bold mb-2">آلبوم پیدا نشد</h1>
            <p className="text-neutral-400 mb-6">
              متاسفانه آلبوم مورد نظر شما یافت نشد.
            </p>
            <button
              onClick={goBack}
              className="inline-flex items-center gap-2 px-6 py-3 bg-green-500 hover:bg-green-400 text-black font-semibold rounded-full transition-colors"
            >
              <Icon name="arrowLeft" className="w-5 h-5 sb-back-icon" />
              بازگشت به خانه
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-linear-to-b from-neutral-900 via-neutral-950 to-black text-white pb-24"
    >
      <SEO
        title={albumData.title}
        description={`شنیدن آلبوم ${albumData.title} از ${albumData.artist_name} در وب اپلیکیشن صداباکس`}
        imageUrl={albumData.cover_image}
        type="music.album"
      />
      <header
        className="relative w-full h-96 md:h-[500px] bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0.6) 50%, rgba(0,0,0,0.8) 100%), url(${albumData.cover_image})`,
        }}
      >
        <div className="absolute top-4 left-4 z-20 sb-back-position">
          <button
            onClick={goBack}
            className="w-12 h-12 rounded-full bg-black/50 hover:bg-black/70 flex items-center justify-center transition-all duration-300 hover:scale-105"
          >
            <Icon name="arrowLeft" className="w-6 h-6 text-white sb-back-icon" />
          </button>
        </div>

        <div className="absolute inset-0 flex items-end justify-end px-6 md:px-12 pb-8">
          <div className="text-start max-w-lg w-full">
            <p className="text-sm font-semibold text-green-400 mb-2 uppercase tracking-wide">
              آلبوم
            </p>
            <h1 className="text-4xl md:text-6xl lg:text-8xl font-black mb-4 text-white drop-shadow-lg">
              {albumData.title}
            </h1>
            {albumData.description && (
              <p className="text-neutral-200 text-base md:text-lg mb-6 leading-relaxed">
                {albumData.description}
              </p>
            )}
            <div className="flex items-center gap-3 text-sm text-neutral-300">
              <button
                onClick={() =>
                  navigateTo("artist-detail", {
                    id: albumData.artist_id,
                    urlSlug: albumData.artist_url_slug || undefined,
                  })
                }
                className="font-medium hover:underline cursor-pointer"
              >
                {albumData.artist_name}
              </button>
              {albumData.release_date && (
                <>
                  <span>•</span>
                  <span>{new Date(albumData.release_date).getFullYear()}</span>
                </>
              )}
              <span>•</span>
              <span>{albumSongs.length} آهنگ</span>
            </div>
          </div>
        </div>

        <div className="absolute top-4 right-4 sb-inline-end-position z-20 flex gap-2">
          <div className="px-3 py-1 text-xs font-bold bg-green-500 text-black rounded-full shadow-lg">
            آلبوم
          </div>
        </div>
      </header>

      <div className="sticky top-0 z-30 bg-linear-to-b from-neutral-950/95 to-neutral-950 px-6 md:px-12 py-6 border-b border-white/10">
        <div className="flex items-center gap-6">
          <button
            onClick={handlePlayAll}
            className="w-16 h-16 rounded-full bg-green-500 hover:bg-green-400 hover:scale-110 flex items-center justify-center shadow-2xl transition-all duration-300"
          >
            {isPlayerPlaying &&
            albumSongs.some((s) => String(s.id) === currentTrack?.id) ? (
              <Icon name="pause" className="w-7 h-7 text-black" />
            ) : (
              <Icon name="play" className="w-7 h-7 text-black ml-1" />
            )}
          </button>

          <button className="w-12 h-12 rounded-full hover:bg-white/10 flex items-center justify-center text-neutral-400 hover:text-green-500 transition-colors duration-200">
            <Icon name="shuffle" className="w-7 h-7" />
          </button>

          <button
            onClick={handleLike}
            disabled={liking}
            className={`w-12 h-12 rounded-full hover:bg-white/10 flex items-center justify-center transition-colors duration-200 ${
              isLiked ? "text-green-500" : "text-neutral-400 hover:text-white"
            } ${liking ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            {liking ? (
              <div className="w-7 h-7 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <Icon name="heart" className="w-7 h-7" fill={isLiked} />
            )}
          </button>

          <button
            onClick={handleShare}
            className="w-12 h-12 rounded-full hover:bg-white/10 flex items-center justify-center text-neutral-400 hover:text-white transition-colors duration-200"
          >
            <Icon name="shareNetwork" className="w-7 h-7" />
          </button>

          <button className="w-12 h-12 rounded-full hover:bg-white/10 flex items-center justify-center text-neutral-400 hover:text-white transition-colors duration-200">
            <Icon name="dotsThree" className="w-7 h-7" />
          </button>
        </div>
      </div>

      <main className="px-6 md:px-12">
        <div className="grid grid-cols-[16px_4fr_minmax(80px,1fr)] md:grid-cols-[16px_4fr_2fr_minmax(80px,1fr)] gap-4 px-4 py-3 border-b border-white/10 text-neutral-400 text-sm font-medium">
          <div className="flex items-center justify-center">#</div>
          <div>Title</div>
          <div className="hidden md:block">Date Added</div>
          <div className="flex items-center justify-end">
            <Icon name="clock" className="w-[18px] h-[18px]" />
          </div>
        </div>

        <div className="mt-4 space-y-1">
          {albumSongs.map((song, index) => (
            <SongRow
              key={song.id}
              song={song}
              index={index}
              isPlaying={
                String(song.id) === currentTrack?.id && isPlayerPlaying
              }
              onPlay={() => handlePlaySong(index)}
              onMore={handleMore}
              onTitleClick={() =>
                navigateTo("song-detail", {
                  id: song.id,
                  urlSlug: getCanonicalSlug(song, getSongDisplayTitle(song)),
                })
              }
              onArtistClick={() =>
                (song.artist_id || albumData.artist_id) &&
                navigateTo("artist-detail", {
                  id: song.artist_id || albumData.artist_id,
                })
              }
            />
          ))}
          {albumSongs.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-center text-neutral-500">
              <Icon name="music" className="mb-3 h-10 w-10 opacity-50" />
              <p className="text-sm font-medium">هنوز آهنگی برای این آلبوم منتشر نشده است.</p>
            </div>
          )}
        </div>
      </main>

      <div className="fixed bottom-0 left-0 right-0 h-24 bg-linear-to-t from-black via-black/95 to-transparent pointer-events-none" />

      <SongOptionsDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        song={selectedSong}
        onAction={handleAction}
      />
    </div>
  );
};

export default AlbumDetail;
